# Installation
Install the below libraries to run the code without issues.
- random
- matplotlib
- numpy
- time

Install all libraries using the command below and replace `<name>` with above options.
```
pip3 install <name>
```
# Code run

To run the code file, run command:
```
python3 dynamic_infomed_rrt_star.py
```

# Results
Please refer the report for detailed results. The code generates visualizations for initial planned path, local plannign around the dynamic obstacle and the updated path (might have high execution time depending on the start and goal positions).